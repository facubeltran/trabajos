

package test;

import entities.AutoClasico;
import entities.AutoNuevo;
import entities.Radio;


public class test {
    public static void main(String[] args) {
        
        AutoNuevo auto1=new AutoNuevo(new Radio("sony"),"rosa", "fiat",2009,440000);
        System.out.println(auto1);
        
        System.out.println("*****************Cambio de radio autoNuevo****************");
        auto1.getRadio().cambiarRadio("JB");
        System.out.println(auto1);
        
        System.out.println("**********************************************************************************");
        
        AutoClasico clasicoConRadio = new AutoClasico("Pirelli", new Radio("amazon"), "verde","toyota", 1978, 481300);
        System.out.println(clasicoConRadio);
        System.out.println("*********cambio de radio*********");
        clasicoConRadio.getRadio().cambiarRadio("Sanyo");
        System.out.println(clasicoConRadio);
        
        
        AutoClasico clasicoSinRadio = new AutoClasico("Pirelli" , "marron", "chevrolet", 1976, 988000);
        System.out.println(clasicoSinRadio);
        // agrego una radio
        clasicoSinRadio.getRadio().agregarRadio("Xiaomi");
        System.out.println("************************agrego una radio****************************");
        System.out.println(clasicoSinRadio);
        
    }
}
