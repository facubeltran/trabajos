
package entities;


public class AutoClasico extends Vehiculo{
    private String tipoDeNeumatico;
    private Radio radio;
    
    public AutoClasico(String tipoDeNeumatico, String color, String marca, int modelo, int precio) {
        super(color, marca, modelo, precio);
        this.tipoDeNeumatico = tipoDeNeumatico;
        this.radio=new Radio("sin radio");
    }

    public AutoClasico(String tipoDeNeumatico, Radio radio, String color, String marca, int modelo, int precio) {
        super(color, marca, modelo);
        this.tipoDeNeumatico = tipoDeNeumatico;
        this.radio = radio;
    }

    @Override
    public String toString() {
        return "AutoClasico{" + "tipoDeNeumatico=" + tipoDeNeumatico + ", radio=" + radio +" , " +super.toString()+'}';
    }

    
 


    public String getTipoDeNeumatico() {
        return tipoDeNeumatico;
    }

    public void setTipoDeNeumatico(String tipoDeNeumatico) {
        this.tipoDeNeumatico = tipoDeNeumatico;
    }

    public Radio getRadio() {
        return radio;
    }

    public void setRadio(Radio radio) {
        this.radio = radio;
    }

  
    
    
}
