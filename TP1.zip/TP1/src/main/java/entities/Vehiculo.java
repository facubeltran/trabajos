package entities;

public class Vehiculo {
    private String color;
    private String marca;
    private int modelo;
    private int precio;

    public Vehiculo(String color, String marca, int modelo) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        
    }

    public Vehiculo(String color, String marca, int modelo, int precio) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Vehiculo{" + "color=" + color + ", marca=" + marca + ", modelo=" + modelo + ", precio=" + precio + '}';
    }


    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMarca() {
        return marca;
    }

    public int getModelo() {
        return modelo;
    }
    
    public void setPrecio(int precio) {
        this.precio = precio;
    }

}
