package entities;


public class Radio {
    private String marcaRadio;

    public Radio(String marcaRadio) {
        this.marcaRadio = marcaRadio;
    }

    
    public void cambiarRadio(String radio){
        marcaRadio=radio;
    }
    public void agregarRadio(String radio){
        marcaRadio=radio;
    }
    
    @Override
    public String toString() {
        return "Radio{" + "marcaRadio=" + marcaRadio + '}';
    }

    public String getMarcaRadio() {
        return marcaRadio;
    }


}
