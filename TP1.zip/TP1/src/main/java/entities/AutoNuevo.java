
package entities;


public class AutoNuevo extends Vehiculo{
    private Radio radio;

    public AutoNuevo(Radio radio, String color, String marca, int modelo, int precio) {
        super(color, marca, modelo, precio);
        this.radio = radio;
    }

    @Override
    public String toString() {
        return "AutoNuevo{" + "radio=" + radio +" , " + super.toString()+'}';
    }

    public Radio getRadio() {
        return radio;
    }


    
    
}
